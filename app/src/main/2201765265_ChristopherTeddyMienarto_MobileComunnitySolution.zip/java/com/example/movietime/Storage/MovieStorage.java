package com.example.movietime.Storage;

import com.example.movietime.Fragment.SavedMovieFragment;
import com.example.movietime.Model.Movie;

import java.util.ArrayList;

public class MovieStorage {
    public static SavedMovieFragment savedMovieFragment;
}
